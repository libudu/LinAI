//! Host port-forward adapter backed by the data-plane runtime.

use std::{
    collections::HashMap,
    net::SocketAddr,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};

use crossbeam_utils::atomic::AtomicCell;
use dashmap::DashMap;
use quanta::Instant;
use tokio::{
    select,
    sync::{Mutex, OwnedMutexGuard, OwnedSemaphorePermit, Semaphore},
    task::{JoinHandle, JoinSet},
};
use tokio_util::{
    sync::CancellationToken,
    task::{AbortOnDropHandle, TaskTracker},
};

use crate::{
    config::{gateway::PortForwardConfig, runtime::CoreRuntimeConfigStore},
    events::{CoreEvent, CoreEventSink},
    foundation::task::reap_joinset_background,
    gateway::dataplane::{
        DataPlaneConsumerLease, DataPlaneRuntime, DataPlaneTcpConnectOptions, DataPlaneTcpStream,
        DataPlaneUdpSocket,
    },
    socket::{
        SocketContext,
        tcp::{
            TcpListenOptions, TcpSocketPurpose, VirtualTcpListener, VirtualTcpListenerFactory,
            VirtualTcpSocket, VirtualTcpSocketFactory,
        },
        udp::{UdpBindOptions, VirtualUdpSocket, VirtualUdpSocketFactory},
    },
};

const MAX_UDP_PAYLOAD_SIZE: usize = 65_507;
const TCP_PORT_FORWARD_REBIND_DELAY: Duration = Duration::from_millis(100);
// A remote flow owns roughly 320 KiB of smoltcp and response buffers.
// Keep the per-instance worst case near 80 MiB instead of allowing a
// source-port flood to grow the WASM heap without bound.
const MAX_ACTIVE_UDP_CLIENTS: usize = 256;

#[derive(Debug, Eq, PartialEq, Hash, Clone)]
struct UdpClientKey {
    client_addr: SocketAddr,
    forward: PortForwardConfig,
}

enum PortForwardUdpFlow<H>
where
    H: VirtualUdpSocketFactory,
{
    Host(Arc<H::Socket>),
    DataPlane(Arc<DataPlaneUdpSocket>),
}

impl<H> PortForwardUdpFlow<H>
where
    H: VirtualUdpSocketFactory,
{
    async fn send_to(&self, buf: &[u8], addr: SocketAddr) -> std::io::Result<usize> {
        match self {
            Self::Host(socket) => socket.send_to(buf, addr).await,
            Self::DataPlane(socket) => socket.send_to(buf, addr).await,
        }
    }

    async fn recv_from(&self, buf: &mut [u8]) -> std::io::Result<(usize, SocketAddr)> {
        match self {
            Self::Host(socket) => socket.recv_from(buf).await,
            Self::DataPlane(socket) => socket.recv_from(buf).await,
        }
    }
}

struct UdpClientInfo<H>
where
    H: VirtualUdpSocketFactory,
{
    flow: Arc<PortForwardUdpFlow<H>>,
    last_active: AtomicCell<Instant>,
    _slot: Arc<OwnedSemaphorePermit>,
}

struct UdpClientReservation {
    slot: OwnedSemaphorePermit,
    admission: OwnedMutexGuard<()>,
}

struct PortForwardListener {
    config: Arc<std::sync::Mutex<PortForwardConfig>>,
    cancel: CancellationToken,
    task: AbortOnDropHandle<()>,
    udp_tasks: TaskTracker,
}

enum PortForwardSocket<H: VirtualTcpListenerFactory + VirtualUdpSocketFactory> {
    Tcp(Arc<H::Listener>),
    Udp(Arc<<H as VirtualUdpSocketFactory>::Socket>),
}

/// Bound additions stay private until persistence and validation have succeeded.
/// Dropping a prepared update leaves every existing listener and target intact.
pub(crate) struct PreparedPortForwards<H>
where
    H: VirtualTcpSocketFactory + VirtualTcpListenerFactory + VirtualUdpSocketFactory,
{
    adapter: Arc<PortForwardAdapter<H>>,
    configs: HashMap<(String, SocketAddr), PortForwardConfig>,
    sockets: Vec<(PortForwardConfig, PortForwardSocket<H>)>,
    consumer_lease: Option<DataPlaneConsumerLease>,
    // Release prepared sockets before allowing another update to bind them.
    operation: OwnedMutexGuard<()>,
}

impl<H> PreparedPortForwards<H>
where
    H: VirtualTcpSocketFactory + VirtualTcpListenerFactory + VirtualUdpSocketFactory,
{
    /// All fallible work is complete. Publish targets and start the bound sockets
    /// without yielding, then retain the operation lock until removals release
    /// their sockets, even if the caller stops waiting for this cleanup.
    pub(crate) fn commit(self) -> JoinHandle<()> {
        let Self {
            adapter,
            operation,
            configs,
            sockets,
            consumer_lease,
        } = self;
        let _runtime = adapter.runtime_handle.as_ref().map(|handle| handle.enter());
        let mut listeners = adapter.listeners.lock().unwrap();
        let mut removed = Vec::new();
        let mut response_tasks = Vec::new();
        let removed_keys = listeners
            .keys()
            .filter(|key| !configs.contains_key(*key))
            .cloned()
            .collect::<Vec<_>>();
        for key in removed_keys {
            let listener = listeners.remove(&key).unwrap();
            listener.cancel.cancel();
            listener.task.abort();
            {
                let current = listener.config.lock().unwrap();
                tracing::info!(?current, "port-forward removed by runtime config reload");
                adapter.remove_udp_clients(&current, &mut response_tasks);
            }
            removed.push(listener);
        }
        for (key, listener) in listeners.iter() {
            let mut current = listener.config.lock().unwrap();
            if let Some(next) = configs.get(key)
                && *current != *next
            {
                adapter.remove_udp_clients(&current, &mut response_tasks);
                *current = next.clone();
                adapter
                    .events
                    .emit(CoreEvent::GatewayPortForwardAdded(next.clone()));
            }
        }
        for (cfg, socket) in sockets {
            let key = (cfg.proto.clone(), cfg.bind_addr);
            let listener = match socket {
                PortForwardSocket::Tcp(socket) => adapter.add_tcp_port_forward(&cfg, socket),
                PortForwardSocket::Udp(socket) => adapter.add_udp_port_forward(&cfg, socket),
            };
            listeners.insert(key, listener);
            adapter.events.emit(CoreEvent::GatewayPortForwardAdded(cfg));
        }
        drop(listeners);
        let mut lease = adapter.consumer_lease.lock().unwrap();
        if let Some(consumer_lease) = consumer_lease {
            lease.replace(consumer_lease);
        }
        let released_lease = if configs.is_empty() {
            lease.take()
        } else {
            None
        };
        drop(lease);
        tokio::spawn(async move {
            let _operation = operation;
            for listener in removed {
                let _ = listener.task.await;
                listener.udp_tasks.close();
                listener.udp_tasks.wait().await;
            }
            for task in response_tasks {
                let _ = task.await;
            }
            drop(released_lease);
        })
    }
}

pub(crate) struct PortForwardAdapter<H>
where
    H: VirtualTcpSocketFactory + VirtualTcpListenerFactory + VirtualUdpSocketFactory,
{
    operation: Arc<Mutex<()>>,
    started: AtomicBool,
    runtime_handle: Option<tokio::runtime::Handle>,
    runtime_config: CoreRuntimeConfigStore,
    data_plane: Arc<DataPlaneRuntime<H>>,
    host: Arc<H>,
    socket_context: SocketContext,
    events: Arc<dyn CoreEventSink>,
    tasks: Arc<std::sync::Mutex<JoinSet<()>>>,
    listeners: std::sync::Mutex<HashMap<(String, SocketAddr), PortForwardListener>>,
    udp_clients: Arc<DashMap<UdpClientKey, Arc<UdpClientInfo<H>>>>,
    udp_response_tasks: Arc<DashMap<UdpClientKey, AbortOnDropHandle<()>>>,
    udp_client_admission: Arc<Mutex<()>>,
    udp_client_slots: Arc<Semaphore>,
    consumer_lease: std::sync::Mutex<Option<DataPlaneConsumerLease>>,
}

impl<H> PortForwardAdapter<H>
where
    H: VirtualTcpSocketFactory + VirtualTcpListenerFactory + VirtualUdpSocketFactory,
{
    pub(crate) fn new(
        runtime_config: CoreRuntimeConfigStore,
        data_plane: Arc<DataPlaneRuntime<H>>,
        host: Arc<H>,
        socket_context: SocketContext,
        events: Arc<dyn CoreEventSink>,
        runtime_handle: Option<tokio::runtime::Handle>,
    ) -> Arc<Self> {
        Arc::new(Self {
            operation: Arc::new(Mutex::new(())),
            started: AtomicBool::new(false),
            runtime_handle,
            runtime_config,
            data_plane,
            host,
            socket_context,
            events,
            tasks: Arc::new(std::sync::Mutex::new(JoinSet::new())),
            listeners: std::sync::Mutex::new(HashMap::new()),
            udp_clients: Arc::new(DashMap::new()),
            udp_response_tasks: Arc::new(DashMap::new()),
            udp_client_admission: Arc::new(Mutex::new(())),
            udp_client_slots: Arc::new(Semaphore::new(MAX_ACTIVE_UDP_CLIENTS)),
            consumer_lease: std::sync::Mutex::new(None),
        })
    }

    pub(crate) async fn start(self: &Arc<Self>) -> anyhow::Result<()> {
        let operation = self.operation.clone().lock_owned().await;
        if self.started.load(Ordering::Acquire) {
            return Ok(());
        }
        self.tasks.lock().unwrap().spawn(reap_joinset_background(
            Arc::downgrade(&self.tasks),
            "port-forward adapter",
        ));
        self.start_udp_reaper();
        let cfgs = self
            .runtime_config
            .snapshot()
            .services
            .gateway
            .port_forwards
            .clone();
        let prepared = match self.prepare_inner(&cfgs, operation).await {
            Ok(prepared) => prepared,
            Err(error) => {
                self.stop_inner().await;
                return Err(error);
            }
        };
        let cleanup = prepared.commit();
        self.started.store(true, Ordering::Release);
        let _ = cleanup.await;
        Ok(())
    }

    pub(crate) async fn prepare(
        self: &Arc<Self>,
        cfgs: &[PortForwardConfig],
    ) -> anyhow::Result<Option<PreparedPortForwards<H>>> {
        if let Some(runtime) = &self.runtime_handle {
            let adapter = self.clone();
            let cfgs = cfgs.to_vec();
            // Binding must happen on the instance executor, including reloads
            // reached through management config patches.
            return AbortOnDropHandle::new(
                runtime.spawn(async move { adapter.prepare_on_runtime(&cfgs).await }),
            )
            .await
            .map_err(|error| anyhow::anyhow!("port-forward prepare task failed: {error}"))?;
        }
        self.prepare_on_runtime(cfgs).await
    }

    async fn prepare_on_runtime(
        self: &Arc<Self>,
        cfgs: &[PortForwardConfig],
    ) -> anyhow::Result<Option<PreparedPortForwards<H>>> {
        let operation = self.operation.clone().lock_owned().await;
        if !self.started.load(Ordering::Acquire) {
            return Ok(None);
        }
        self.prepare_inner(cfgs, operation).await.map(Some)
    }

    async fn prepare_inner(
        self: &Arc<Self>,
        cfgs: &[PortForwardConfig],
        operation: OwnedMutexGuard<()>,
    ) -> anyhow::Result<PreparedPortForwards<H>> {
        let mut configs = HashMap::new();
        for cfg in cfgs {
            let mut cfg = cfg.clone();
            cfg.proto.make_ascii_lowercase();
            if !matches!(cfg.proto.as_str(), "tcp" | "udp") {
                anyhow::bail!(
                    "unsupported protocol: {}, only support udp / tcp",
                    cfg.proto
                );
            }
            let key = (cfg.proto.clone(), cfg.bind_addr);
            if let Some(previous) = configs.insert(key, cfg.clone()) {
                anyhow::ensure!(
                    previous == cfg,
                    "conflicting port-forward targets for {} {}",
                    cfg.proto,
                    cfg.bind_addr
                );
            }
        }
        let consumer_lease = if !configs.is_empty() && self.consumer_lease.lock().unwrap().is_none()
        {
            Some(self.data_plane.acquire_consumer_lease()?)
        } else {
            None
        };
        let mut sockets = Vec::new();
        for cfg in cfgs {
            let mut cfg = cfg.clone();
            cfg.proto.make_ascii_lowercase();
            let key = (cfg.proto.clone(), cfg.bind_addr);
            if self.listeners.lock().unwrap().contains_key(&key)
                || sockets
                    .iter()
                    .any(|(bound, _): &(PortForwardConfig, PortForwardSocket<H>)| {
                        bound.proto == cfg.proto && bound.bind_addr == cfg.bind_addr
                    })
            {
                continue;
            }
            let socket = if cfg.proto == "tcp" {
                PortForwardSocket::Tcp(
                    self.host
                        .bind_tcp(self.tcp_listen_options(cfg.bind_addr))
                        .await?,
                )
            } else {
                PortForwardSocket::Udp(
                    self.host
                        .bind_udp(
                            UdpBindOptions::port_forward(cfg.bind_addr)
                                .with_context(self.socket_context.clone()),
                        )
                        .await?,
                )
            };
            sockets.push((cfg, socket));
        }
        Ok(PreparedPortForwards {
            adapter: self.clone(),
            operation,
            configs,
            sockets,
            consumer_lease,
        })
    }

    fn tcp_listen_options(&self, bind_addr: SocketAddr) -> TcpListenOptions {
        let options = TcpListenOptions::port_forward(bind_addr);
        let bind = options
            .bind
            .clone()
            .with_context(self.socket_context.clone());
        options.with_bind(bind)
    }

    fn remove_udp_clients(&self, cfg: &PortForwardConfig, tasks: &mut Vec<AbortOnDropHandle<()>>) {
        self.udp_clients.retain(|key, _| key.forward != *cfg);
        let keys = self
            .udp_response_tasks
            .iter()
            .filter(|entry| entry.key().forward == *cfg)
            .map(|entry| entry.key().clone())
            .collect::<Vec<_>>();
        for key in keys {
            if let Some((_, task)) = self.udp_response_tasks.remove(&key) {
                task.abort();
                tasks.push(task);
            }
        }
    }

    fn add_tcp_port_forward(
        &self,
        cfg: &PortForwardConfig,
        listener: Arc<H::Listener>,
    ) -> PortForwardListener {
        let (bind_addr, dst_addr) = (cfg.bind_addr, cfg.dst_addr);
        let options = self.tcp_listen_options(bind_addr);
        tracing::info!(?bind_addr, ?dst_addr, "TCP port-forward listener bound");
        let cancel = CancellationToken::new();
        let config = Arc::new(std::sync::Mutex::new(cfg.clone()));
        let task_cancel = cancel.clone();
        let task_config = config.clone();

        let data_plane = self.data_plane.clone();
        let connections = Arc::new(std::sync::Mutex::new(JoinSet::new()));
        connections.lock().unwrap().spawn(reap_joinset_background(
            Arc::downgrade(&connections),
            "TCP port-forward connections",
        ));
        let host = self.host.clone();
        let task = AbortOnDropHandle::new(tokio::spawn(async move {
            let cancel = task_cancel;
            let mut listener = Some(listener);
            loop {
                let Some((incoming, source_addr)) =
                    accept_tcp_port_forward(&host, &options, &mut listener, &cancel).await
                else {
                    break;
                };
                let dst_addr = task_config.lock().unwrap().dst_addr;
                tracing::info!(
                    ?bind_addr,
                    ?source_addr,
                    ?dst_addr,
                    "port-forward accepted local connection"
                );
                let data_plane = data_plane.clone();
                connections.lock().unwrap().spawn(async move {
                    tracing::info!(
                        ?source_addr,
                        ?dst_addr,
                        "port-forward data-plane connect started"
                    );
                    let options = DataPlaneTcpConnectOptions::gateway(
                        Duration::from_secs(10),
                        TcpSocketPurpose::PortForward,
                        source_addr,
                    );
                    let outgoing = match data_plane.connect_tcp(dst_addr, options).await {
                        Ok(stream) => stream,
                        Err(error) => {
                            tracing::error!(?error, ?dst_addr, "port-forward connect failed");
                            return;
                        }
                    };
                    tracing::info!(?source_addr, ?dst_addr, "port-forward data-plane connected");
                    copy_tcp(incoming, outgoing, dst_addr).await;
                });
            }
            tracing::info!(
                ?bind_addr,
                ?dst_addr,
                "TCP port-forward listener task stopped"
            );
        }));
        PortForwardListener {
            config,
            cancel,
            task,
            udp_tasks: TaskTracker::new(),
        }
    }

    fn add_udp_port_forward(
        &self,
        cfg: &PortForwardConfig,
        socket: Arc<<H as VirtualUdpSocketFactory>::Socket>,
    ) -> PortForwardListener {
        let bind_addr = cfg.bind_addr;
        let cancel = CancellationToken::new();
        let config = Arc::new(std::sync::Mutex::new(cfg.clone()));
        let task_cancel = cancel.clone();
        let task_config = config.clone();
        let udp_tasks = TaskTracker::new();
        let response_tracker = udp_tasks.clone();

        let data_plane = self.data_plane.clone();
        let host = self.host.clone();
        let socket_context = self.socket_context.clone();
        let udp_clients = self.udp_clients.clone();
        let response_tasks = self.udp_response_tasks.clone();
        let client_admission = self.udp_client_admission.clone();
        let client_slots = self.udp_client_slots.clone();
        let task = AbortOnDropHandle::new(tokio::spawn(async move {
            let cancel = task_cancel;
            let adapter = UdpFlowFactory {
                data_plane,
                host,
                socket_context,
            };
            let mut buf = vec![0u8; MAX_UDP_PAYLOAD_SIZE];
            loop {
                let (len, client_addr) = select! {
                    biased;
                    _ = cancel.cancelled() => break,
                    result = socket.recv_from(&mut buf) => match result {
                        Ok(packet) => packet,
                        Err(error) => {
                            tracing::error!(?error, ?bind_addr, "UDP port-forward receive failed");
                            continue;
                        }
                    },
                };
                let forward = task_config.lock().unwrap().clone();
                let dst_addr = forward.dst_addr;
                let key = UdpClientKey {
                    client_addr,
                    forward: forward.clone(),
                };
                let flow = match udp_clients.get(&key) {
                    Some(client) => client.clone(),
                    None => {
                        let flow = match adapter.open(dst_addr).await {
                            Ok(flow) => flow,
                            Err(error) => {
                                tracing::error!(
                                    ?error,
                                    ?dst_addr,
                                    "open UDP data-plane flow failed"
                                );
                                continue;
                            }
                        };
                        let Some(reservation) = reserve_udp_client_slot(
                            &cancel,
                            &client_admission,
                            &client_slots,
                            &udp_clients,
                            &response_tasks,
                        )
                        .await
                        else {
                            tracing::trace!(
                                ?client_addr,
                                "UDP port-forward client limit remains full"
                            );
                            continue;
                        };
                        let UdpClientReservation { slot, admission } = reservation;
                        // Commit uses this same lock when replacing the target
                        // and removing its flows. Do not publish an old flow
                        // after either operation, including after an async open.
                        let current = task_config.lock().unwrap();
                        if *current != forward || cancel.is_cancelled() {
                            continue;
                        }
                        let slot = Arc::new(slot);
                        let client = Arc::new(UdpClientInfo {
                            flow: flow.clone(),
                            last_active: AtomicCell::new(Instant::now()),
                            _slot: slot.clone(),
                        });
                        udp_clients.insert(key.clone(), client.clone());

                        let inbound = socket.clone();
                        let response_flow = flow.clone();
                        let response_client = client_addr;
                        let response_slot = slot;
                        response_tasks.insert(
                            key.clone(),
                            AbortOnDropHandle::new(response_tracker.spawn(async move {
                                let _slot = response_slot;
                                let mut buf = vec![0u8; MAX_UDP_PAYLOAD_SIZE];
                                loop {
                                    match response_flow.recv_from(&mut buf).await {
                                        Ok((len, remote)) => {
                                            tracing::trace!(
                                                ?remote,
                                                ?response_client,
                                                len,
                                                "forwarding UDP data-plane response"
                                            );
                                            if let Err(error) =
                                                inbound.send_to(&buf[..len], response_client).await
                                            {
                                                tracing::error!(?error, "send UDP response failed");
                                                return;
                                            }
                                        }
                                        Err(error) => {
                                            tracing::error!(?error, "receive UDP response failed");
                                            return;
                                        }
                                    }
                                }
                            })),
                        );
                        drop(current);
                        drop(admission);
                        client
                    }
                };
                flow.last_active.store(Instant::now());
                if let Err(error) = flow.flow.send_to(&buf[..len], dst_addr).await {
                    tracing::error!(?error, ?dst_addr, "send UDP data-plane packet failed");
                }
            }
        }));

        PortForwardListener {
            config,
            cancel,
            task,
            udp_tasks,
        }
    }

    fn start_udp_reaper(&self) {
        let udp_clients = self.udp_clients.clone();
        let response_tasks = self.udp_response_tasks.clone();
        self.tasks.lock().unwrap().spawn(async move {
            loop {
                crate::foundation::time::sleep(Duration::from_secs(30)).await;
                let now = Instant::now();
                udp_clients.retain(|_, client| {
                    now.duration_since(client.last_active.load()).as_secs() < 600
                });
                response_tasks.retain(|key, _| udp_clients.contains_key(key));
                udp_clients.shrink_to_fit();
                response_tasks.shrink_to_fit();
            }
        });
    }

    async fn stop_inner(&self) {
        self.started.store(false, Ordering::Release);
        let listeners = std::mem::take(&mut *self.listeners.lock().unwrap());
        tracing::info!(
            forward_count = listeners.len(),
            "port-forward adapter stopping"
        );
        for listener in listeners.values() {
            listener.cancel.cancel();
            listener.task.abort();
        }
        // First stop publishers, then remove response handles. The trackers
        // include responses whose handles the reaper/eviction already dropped.
        let mut trackers = Vec::new();
        for (_, listener) in listeners {
            let _ = listener.task.await;
            trackers.push(listener.udp_tasks);
        }
        self.udp_response_tasks.clear();
        self.udp_clients.clear();
        for tracker in trackers {
            tracker.close();
            tracker.wait().await;
        }
        self.consumer_lease.lock().unwrap().take();
        let mut tasks = {
            let mut tasks = self.tasks.lock().unwrap();
            std::mem::replace(&mut *tasks, JoinSet::new())
        };
        tasks.shutdown().await;
    }

    pub(crate) async fn stop(&self) {
        let _operation = self.operation.lock().await;
        self.stop_inner().await;
    }
}

async fn accept_tcp_port_forward<H>(
    host: &Arc<H>,
    options: &TcpListenOptions,
    listener: &mut Option<Arc<H::Listener>>,
    cancel: &CancellationToken,
) -> Option<(<H::Listener as VirtualTcpListener>::Socket, SocketAddr)>
where
    H: VirtualTcpListenerFactory,
{
    loop {
        let current = listener
            .take()
            .expect("TCP port-forward listener must be bound before accepting");
        let accepted = select! {
            biased;
            _ = cancel.cancelled() => {
                tracing::info!(?options, "port-forward listener cancelled while accepting");
                return None;
            },
            result = current.accept() => result,
        };
        match accepted {
            Ok(accepted) => {
                listener.replace(current);
                return Some(accepted);
            }
            Err(error) => {
                tracing::error!(?error, ?options, "port-forward accept failed; rebinding");
            }
        }
        drop(current);

        loop {
            select! {
                biased;
                _ = cancel.cancelled() => {
                    tracing::info!(?options, "port-forward listener cancelled during rebind delay");
                    return None;
                },
                _ = crate::foundation::time::sleep(TCP_PORT_FORWARD_REBIND_DELAY) => {}
            }
            let rebound = select! {
                biased;
                _ = cancel.cancelled() => {
                    tracing::info!(?options, "port-forward listener cancelled while rebinding");
                    return None;
                },
                result = host.bind_tcp(options.clone()) => result,
            };
            match rebound {
                Ok(rebound) => {
                    tracing::info!(?options, "port-forward listener rebound");
                    listener.replace(rebound);
                    break;
                }
                Err(error) => {
                    tracing::error!(?error, ?options, "port-forward listener rebind failed");
                }
            }
        }
    }
}

async fn reserve_udp_client_slot<H>(
    cancel: &CancellationToken,
    admission: &Arc<Mutex<()>>,
    slots: &Arc<Semaphore>,
    clients: &DashMap<UdpClientKey, Arc<UdpClientInfo<H>>>,
    response_tasks: &DashMap<UdpClientKey, AbortOnDropHandle<()>>,
) -> Option<UdpClientReservation>
where
    H: VirtualUdpSocketFactory,
{
    // Keep eviction, permit handoff, and publication in one critical section.
    let admission = select! {
        biased;
        _ = cancel.cancelled() => return None,
        admission = admission.clone().lock_owned() => admission,
    };
    loop {
        if let Ok(slot) = slots.clone().try_acquire_owned() {
            return Some(UdpClientReservation { slot, admission });
        }

        let oldest = clients
            .iter()
            .min_by_key(|entry| entry.value().last_active.load())
            .map(|entry| entry.key().clone())?;
        let Some(evicted) = clients.remove(&oldest) else {
            continue;
        };
        drop(response_tasks.remove(&oldest));
        drop(evicted);
        let slot = select! {
            biased;
            _ = cancel.cancelled() => return None,
            slot = slots.clone().acquire_owned() => slot.ok()?,
        };
        return Some(UdpClientReservation { slot, admission });
    }
}

struct UdpFlowFactory<H>
where
    H: VirtualTcpSocketFactory + VirtualTcpListenerFactory + VirtualUdpSocketFactory,
{
    data_plane: Arc<DataPlaneRuntime<H>>,
    host: Arc<H>,
    socket_context: SocketContext,
}

impl<H> UdpFlowFactory<H>
where
    H: VirtualTcpSocketFactory + VirtualTcpListenerFactory + VirtualUdpSocketFactory,
{
    async fn open(&self, dst_addr: SocketAddr) -> anyhow::Result<Arc<PortForwardUdpFlow<H>>> {
        if self.data_plane.is_local_virtual_ip(dst_addr.ip()) {
            let socket = self
                .host
                .bind_udp(
                    UdpBindOptions::port_lease("0.0.0.0:0".parse().unwrap())
                        .with_context(self.socket_context.clone()),
                )
                .await?;
            Ok(Arc::new(PortForwardUdpFlow::Host(socket)))
        } else {
            let socket = self
                .data_plane
                .data_plane_udp_bind(0, Duration::from_secs(10))
                .await?;
            Ok(Arc::new(PortForwardUdpFlow::DataPlane(Arc::new(socket))))
        }
    }
}

async fn copy_tcp<S>(mut incoming: S, mut outgoing: DataPlaneTcpStream, dst_addr: SocketAddr)
where
    S: VirtualTcpSocket,
{
    match tokio::io::copy_bidirectional(&mut incoming, &mut outgoing).await {
        Ok((from_client, from_server)) => tracing::info!(
            ?dst_addr,
            from_client,
            from_server,
            "port-forward connection finished"
        ),
        Err(error) => tracing::error!(?error, ?dst_addr, "port-forward connection failed"),
    }
}

#[cfg(test)]
mod reload_tests;

#[cfg(test)]
mod tests {
    use std::{io, sync::atomic::AtomicUsize};

    use super::*;
    use crate::host::testkit::{TestHost, TestTcpSocket, TestUdpSocket};

    struct RecoveringTcpListener {
        accept_error: bool,
        active: Arc<AtomicUsize>,
        address: SocketAddr,
    }

    impl Drop for RecoveringTcpListener {
        fn drop(&mut self) {
            self.active.fetch_sub(1, Ordering::Relaxed);
        }
    }

    #[async_trait::async_trait]
    impl VirtualTcpListener for RecoveringTcpListener {
        type Socket = TestTcpSocket;

        fn local_addr(&self) -> io::Result<SocketAddr> {
            Ok(self.address)
        }

        async fn accept(&self) -> io::Result<(Self::Socket, SocketAddr)> {
            if self.accept_error {
                return Err(io::Error::other("listener is no longer usable"));
            }
            let (socket, _) = tokio::io::duplex(64);
            Ok((TestTcpSocket(socket), "127.0.0.1:40000".parse().unwrap()))
        }
    }

    #[derive(Default)]
    struct RecoveringTcpHost {
        binds: AtomicUsize,
        active: Arc<AtomicUsize>,
    }

    #[async_trait::async_trait]
    impl VirtualTcpListenerFactory for RecoveringTcpHost {
        type Listener = RecoveringTcpListener;

        async fn bind_tcp(&self, options: TcpListenOptions) -> anyhow::Result<Arc<Self::Listener>> {
            let bind_index = self.binds.fetch_add(1, Ordering::Relaxed);
            if bind_index > 0 && self.active.load(Ordering::Relaxed) != 0 {
                anyhow::bail!("previous listener is still active");
            }
            self.active.fetch_add(1, Ordering::Relaxed);
            Ok(Arc::new(RecoveringTcpListener {
                accept_error: bind_index == 0,
                active: self.active.clone(),
                address: options.bind.local_addr.unwrap(),
            }))
        }
    }

    #[tokio::test]
    async fn tcp_listener_rebinds_after_accept_error() {
        let host = Arc::new(RecoveringTcpHost::default());
        let options = TcpListenOptions::port_forward("127.0.0.1:5202".parse().unwrap());
        let mut listener = Some(host.bind_tcp(options.clone()).await.unwrap());

        let accepted = tokio::time::timeout(
            Duration::from_secs(1),
            accept_tcp_port_forward(&host, &options, &mut listener, &CancellationToken::new()),
        )
        .await
        .unwrap();

        assert!(accepted.is_some());
        assert_eq!(host.binds.load(Ordering::Relaxed), 2);
        assert_eq!(host.active.load(Ordering::Relaxed), 1);
    }

    #[tokio::test]
    async fn tcp_listener_rebind_stops_when_cancelled() {
        let host = Arc::new(RecoveringTcpHost::default());
        let options = TcpListenOptions::port_forward("127.0.0.1:5202".parse().unwrap());
        let mut listener = Some(host.bind_tcp(options.clone()).await.unwrap());
        let cancel = CancellationToken::new();
        let cancel_after_error = cancel.clone();
        tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(10)).await;
            cancel_after_error.cancel();
        });

        let accepted = tokio::time::timeout(
            Duration::from_secs(1),
            accept_tcp_port_forward(&host, &options, &mut listener, &cancel),
        )
        .await
        .unwrap();

        assert!(accepted.is_none());
        assert_eq!(host.binds.load(Ordering::Relaxed), 1);
        assert_eq!(host.active.load(Ordering::Relaxed), 0);
    }

    fn udp_client_key(port: u16) -> UdpClientKey {
        UdpClientKey {
            client_addr: SocketAddr::from(([127, 0, 0, 1], port)),
            forward: PortForwardConfig {
                bind_addr: "127.0.0.1:5202".parse().unwrap(),
                dst_addr: "10.144.0.20:5201".parse().unwrap(),
                proto: "udp".to_owned(),
            },
        }
    }

    fn udp_client(slots: &Arc<Semaphore>, last_active: Instant) -> Arc<UdpClientInfo<TestHost>> {
        udp_client_with_slot(
            Arc::new(slots.clone().try_acquire_owned().unwrap()),
            last_active,
        )
    }

    fn udp_client_with_slot(
        slot: Arc<OwnedSemaphorePermit>,
        last_active: Instant,
    ) -> Arc<UdpClientInfo<TestHost>> {
        let flow: Arc<PortForwardUdpFlow<TestHost>> = Arc::new(PortForwardUdpFlow::Host(Arc::new(
            TestUdpSocket("127.0.0.1:20002".parse().unwrap()),
        )));
        Arc::new(UdpClientInfo {
            flow,
            last_active: AtomicCell::new(last_active),
            _slot: slot,
        })
    }

    fn pending_response_task(slot: Arc<OwnedSemaphorePermit>) -> AbortOnDropHandle<()> {
        AbortOnDropHandle::new(tokio::spawn(async move {
            let _slot = slot;
            std::future::pending().await
        }))
    }

    #[tokio::test]
    async fn udp_client_capacity_evicts_least_recently_active_flow() {
        let slots = Arc::new(Semaphore::new(2));
        let admission = Arc::new(Mutex::new(()));
        let clients: DashMap<UdpClientKey, Arc<UdpClientInfo<TestHost>>> = DashMap::new();
        let response_tasks: DashMap<UdpClientKey, AbortOnDropHandle<()>> = DashMap::new();
        let oldest = udp_client_key(40001);
        let newest = udp_client_key(40002);
        let now = Instant::now();
        let oldest_client = udp_client(&slots, now - Duration::from_secs(2));
        let newest_client = udp_client(&slots, now - Duration::from_secs(1));
        response_tasks.insert(
            oldest.clone(),
            pending_response_task(oldest_client._slot.clone()),
        );
        response_tasks.insert(
            newest.clone(),
            pending_response_task(newest_client._slot.clone()),
        );
        clients.insert(oldest.clone(), oldest_client);
        clients.insert(newest.clone(), newest_client);
        assert_eq!(slots.available_permits(), 0);

        let replacement = reserve_udp_client_slot(
            &CancellationToken::new(),
            &admission,
            &slots,
            &clients,
            &response_tasks,
        )
        .await
        .unwrap();

        assert!(!clients.contains_key(&oldest));
        assert!(!response_tasks.contains_key(&oldest));
        assert!(clients.contains_key(&newest));
        assert!(response_tasks.contains_key(&newest));
        assert_eq!(slots.available_permits(), 0);

        drop(replacement);
        response_tasks.clear();
        clients.clear();
        tokio::task::yield_now().await;
        assert_eq!(slots.available_permits(), 2);
    }

    #[cfg_attr(
        not(target_os = "wasi"),
        tokio::test(flavor = "multi_thread", worker_threads = 2)
    )]
    #[cfg_attr(target_os = "wasi", tokio::test)]
    async fn udp_client_admission_covers_client_and_response_task_publication() {
        let slots = Arc::new(Semaphore::new(1));
        let admission = Arc::new(Mutex::new(()));
        let clients: Arc<DashMap<UdpClientKey, Arc<UdpClientInfo<TestHost>>>> =
            Arc::new(DashMap::new());
        let response_tasks: Arc<DashMap<UdpClientKey, AbortOnDropHandle<()>>> =
            Arc::new(DashMap::new());
        let oldest = udp_client_key(40001);
        let oldest_client = udp_client(&slots, Instant::now());
        response_tasks.insert(
            oldest.clone(),
            pending_response_task(oldest_client._slot.clone()),
        );
        clients.insert(oldest.clone(), oldest_client.clone());

        let reserve = || {
            let admission = admission.clone();
            let slots = slots.clone();
            let clients = clients.clone();
            let response_tasks = response_tasks.clone();
            tokio::spawn(async move {
                reserve_udp_client_slot(
                    &CancellationToken::new(),
                    &admission,
                    &slots,
                    &clients,
                    &response_tasks,
                )
                .await
            })
        };
        let first = reserve();
        tokio::time::timeout(Duration::from_secs(1), async {
            while clients.contains_key(&oldest) {
                tokio::task::yield_now().await;
            }
        })
        .await
        .unwrap();

        let mut second = reserve();
        assert!(
            tokio::time::timeout(Duration::from_millis(50), &mut second)
                .await
                .is_err()
        );

        drop(oldest_client);
        let first_slot = tokio::time::timeout(Duration::from_secs(1), first)
            .await
            .unwrap()
            .unwrap()
            .unwrap();

        assert!(
            tokio::time::timeout(Duration::from_millis(50), &mut second)
                .await
                .is_err()
        );

        let UdpClientReservation {
            slot,
            admission: admission_guard,
        } = first_slot;
        let replacement = udp_client_key(40002);
        let replacement_slot = Arc::new(slot);
        let replacement_client = udp_client_with_slot(replacement_slot.clone(), Instant::now());
        clients.insert(replacement.clone(), replacement_client.clone());

        assert!(
            tokio::time::timeout(Duration::from_millis(50), &mut second)
                .await
                .is_err()
        );
        assert!(clients.contains_key(&replacement));

        response_tasks.insert(replacement.clone(), pending_response_task(replacement_slot));
        drop(admission_guard);

        // Release the test's permit reference and wait for the full eviction;
        // the client and response-task entries are removed separately.
        drop(replacement_client);
        let second_slot = tokio::time::timeout(Duration::from_secs(1), second)
            .await
            .unwrap()
            .unwrap()
            .unwrap();

        assert!(!clients.contains_key(&replacement));
        assert!(!response_tasks.contains_key(&replacement));

        drop(second_slot);
        tokio::task::yield_now().await;
        assert_eq!(slots.available_permits(), 1);
    }
}
